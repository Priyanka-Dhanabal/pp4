import os

os.environ.setdefault(
    "DATABASE_URL",
    "postgres://ur56j0h1jlh:ZMwd2QFHEV36@ep-gentle-mountain-a23bxz6h.eu-central-1.aws.neon.tech/flame_wake_icon_281335")

os.environ.setdefault(
    "SECRET_KEY",
    "django-insecure-3oad*7uresmzzm87if#&#l1&66s*hue4izp*7#h1hyhw4x&-ll"
    )

os.environ.setdefault(
    "CLOUDINARY_URL",
    "cloudinary://949748523129411:-kEvGLT4nWdhv4YQ8xI8jg6K3qA@dtfaolrui"
    )

# Future feature to include Google app password reset
os.environ.setdefault(
    "EMAIL_USER",
    ""
    )

os.environ.setdefault(
    "EMAIL_PASS",
    ""
)